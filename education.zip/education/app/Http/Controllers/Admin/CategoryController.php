<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function view() {
        return view('admin.categories.view');
    }

    public function add() {
        return view('admin.categories.add');
    }

    public function trash() {
        return view('admin.categories.trash');
    }
}
