<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CourseController extends Controller
{
    public function index () {
        return view('admin.courses.index');
    }

    public function add () {
        return view('admin.courses.add');
    }

    public function curriculum () {
        return view('admin.courses.curriculums.index');
    }

    public function trash () {
        return view('admin.courses.trash');
    }
}
