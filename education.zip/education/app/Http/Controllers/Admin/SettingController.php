<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    public function user_roles () {
        return view('admin.settings.user_roles.index');
    }

    public function user_permissions () {
        return view('admin.settings.user_permissions.index');
    }

    public function courses_type () {
        return view('admin.settings.courses_type.index');
    }

    public function countries () {
        return view('admin.settings.countries.index');
    }

    public function account () {
        return view('admin.settings.accounts.index');
    }
}
