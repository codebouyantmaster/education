<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CommunicationController extends Controller
{
    public function contacts() {
        return view('admin.communications.contacts');
    }

    public function mail_and_sms() {
        return view('admin.communications.mail_and_sms');
    }

    public function spam() {
        return view('admin.communications.spam');
    }
}
