<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ResourceController extends Controller
{
    public function index () {
        return view('admin.resources.index');
    }

    public function add () {
        return view('admin.resources.add');
    }

    public function trash () {
        return view('admin.resources.trash');
    }
}
