<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
    protected $fillable = [
        'iso', 'country_name', 'nicename', 'sio3', 'numcode', 'phonecode', 'created_at', 'updated_at'
    ];
}
