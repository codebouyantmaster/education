<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class UserRoles extends Model
{
    protected $fillable = [
        'name', 'status', 'created_at'
    ];
}
