<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CourseCurriculum extends Model
{
    protected $fillable = [
        'parent_id', 'course_id', 'title', 'content', 'is_media', 'status'
    ];
}
