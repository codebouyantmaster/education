<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Question extends Model
{
    protected $fillable = [
        'course_id', 'user_id', 'question', 'description', 'answer_id', 'status', 'created_at', 'updated_at'
    ];
}
