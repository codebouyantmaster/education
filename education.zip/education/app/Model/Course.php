<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    protected $fillable = [
        'category_id', 'title', 'description', 'slug', 'user_id', 'course_type_id', 'is_featurd', 'is_recommended', 'status', 'created_at', 'updated_at'
    ];
}
