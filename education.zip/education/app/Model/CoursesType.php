<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CoursesType extends Model
{
    protected $fillable = [
        'name', 'status', 'created_at', 'updated_at'
    ];
}
