<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class UserPermission extends Model
{
    protected $fillable = [
        'user_role_id', 'roles'
    ];
}
