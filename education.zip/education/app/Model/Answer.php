<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Answer extends Model
{
    protected $fillable = [
        'parent_id', 'question_id', 'user_id', 'content', 'status', 'created_at', 'updated_at'
    ];
}
