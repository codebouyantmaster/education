<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class GeneralSetting extends Model
{
    protected $fillable = [
        'field_name', 'field_value'
    ];
}
